    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    <script src="http://<?= $_SERVER['HTTP_HOST'] ?>/views/static/js/<?= $title ?>.js" language="JavaScript" type="text/javascript"></script>
</body>
</html>