<?php

namespace Ven\App;

class User {
    
    public function __construct(
        public $info
    ){}  

}